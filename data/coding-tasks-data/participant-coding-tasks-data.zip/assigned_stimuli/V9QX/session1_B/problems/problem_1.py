'''
Implement a function 'secondGreatest' that accepts
a list of integers and returns the second greatest element in the list.

 Example:
  Input:
  values = [4, 9, 1, 7, 3]

  Output:
  7
'''

'''WRITE CODE HERE'''
def secondGreatest(nums):
    sorted_nums = sorted(nums)
    return sorted_nums[len(nums)-2]
