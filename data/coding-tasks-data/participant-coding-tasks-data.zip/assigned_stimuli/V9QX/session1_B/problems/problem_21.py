'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''


def isSorted(nums):
    prev = nums[0]
    for i in range(1, len(nums)):
        if nums[i] < prev:
            return False
      
    return True
