'''
Given a string, 's', and an integer, 'x', update 's'
such that its characters are shifted by x in the ASCII (alphabetical) sequence.

 Ex. s = "cd", x = 1.
 Loop results in s = "de"
'''


'''WRITE CODE HERE'''
result = []
dict = {}
start_l = 97
start_u = 65


for c in "abcdefghijklmnopqrstuvwxyz":
    dict[c] = start_l
    start_l += 1 

for ch in s:
    curr_char = ((dict[ch] + x) - 97 + 1)%26
    result.append(dict[curr_char+97])



