'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


''' WRITE CODE HERE '''
def containsDuplicate(nums):
    mp = {}

    for num in nums:
        if num in mp:
            return True
        mp[num] = 1
  
    return False