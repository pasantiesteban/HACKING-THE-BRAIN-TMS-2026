'''
Write a function 'isPrime' that checks whether a given integer is a prime number.
A prime number (or a prime) is a natural number greater than 1 that is not a product 
of two smaller natural numbers.

 Example:
  Input: 1
  Output: True
'''


'''WRITE CODE HERE'''

def isPrime(num):
    
  factors = 0
  for i in range(1, num):
    if num % i == 0:
      factors += 1
    
  return factors == 1
