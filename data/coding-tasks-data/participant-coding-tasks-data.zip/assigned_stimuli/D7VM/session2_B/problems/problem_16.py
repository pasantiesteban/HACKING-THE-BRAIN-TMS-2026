'''
Write the definition of a function 'isEven' so that it
returns True or False if the int 'n' is even or not.

 Example:
  Input: 4
  Output: True
'''


'''WRITE CODE HERE'''
def isEven(n):
    return True if n % 2 == 0 else False