'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''


'''WRITE CODE HERE'''
def isSorted(val):
    sorted_val = sorted(val)
    for i in range(0, len(val)):
        if val[i] != sorted_val[i]:
            return False
    
    return True