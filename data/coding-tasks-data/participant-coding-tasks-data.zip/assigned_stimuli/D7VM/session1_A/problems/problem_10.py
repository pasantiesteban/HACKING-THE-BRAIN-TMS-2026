'''
Write a function 'isPrime' that checks whether a given integer is a prime number.
A prime number (or a prime) is a natural number greater than 1 that is not a product 
of two smaller natural numbers.

 Example:
  Input: 1
  Output: True
'''


'''WRITE CODE HERE'''
def isPrime(a):
    flag = False
    for i in range(2, a):
        if a/i == int(a/i):
            flag = True
    return flag