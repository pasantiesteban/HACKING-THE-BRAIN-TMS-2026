'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


''' WRITE CODE HERE '''
def containsDuplicate(a):
    flag = False
    for i in range(0, len(a)-1):
        for j in range(i+1, len(a)):
            if a[i] == a[j]:
                flag=True

    return flag