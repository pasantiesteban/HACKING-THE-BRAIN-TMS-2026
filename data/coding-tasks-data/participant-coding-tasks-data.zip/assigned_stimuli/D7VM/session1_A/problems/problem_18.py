'''
Implement a function 'countdown' that accepts an integer 'n' as a parameter and counts down from 'n',
printing each number to standard output, separated by a space. After reaching 0 (zero), print "liftoff!".

 Example:
  Input:
  n = 5

 Output:
  5 4 3 2 1 0 liftoff!
'''


'''WRITE CODE HERE'''
def countdown(a):
    res = ""
    for i in range(a, -1, -1):
        res = res+str(i)+' '
    res = res+"liftoff!"
    return res