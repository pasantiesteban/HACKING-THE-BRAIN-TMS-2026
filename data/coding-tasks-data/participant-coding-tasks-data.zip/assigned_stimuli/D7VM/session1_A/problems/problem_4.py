"""
Complete the assignment of the variable 'isFailing' such that it is set to True if 'exam_score' is
less than 50, and False otherwise.
"""

def checkExam():
    exam_score = int(input())
    isFailing =  True if exam_score < 50 else False
    if isFailing:
        print("You failed!")
    else:
        print("You passed!")
