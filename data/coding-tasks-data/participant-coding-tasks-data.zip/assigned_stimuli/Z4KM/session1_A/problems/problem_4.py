'''
 Complete the definition of the function absoluteValue such that it
 receives an integer parameter and returns the absolute value of the parameter's value.

 Example:
  Input:
  num = -5

  Output after calling absoluteValue(num):
  5
'''

def absoluteValue(num1):
    '''WRITE CODE HERE'''
    return result
