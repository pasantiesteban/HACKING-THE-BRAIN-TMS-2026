''' 
Write the definition of a function min that has two int parameters and returns the smaller.
 Example:
  Input:
  num1 = 8, num2 = 3

  Output after calling min(num1, num2):
  3
'''

def min(num1, num2):
    '''WRITE CODE HERE'''
