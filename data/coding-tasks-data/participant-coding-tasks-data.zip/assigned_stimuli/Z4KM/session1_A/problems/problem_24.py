'''
Complete the definition of a function isSenior, that receives an integer
parameter and returns True if the parameter's value is greater than or equal to 65,
and False otherwise

 Example:
  Input:
  age = 70

  Output after calling isSenior(age):
  True
'''

def isSenior(age):
    '''WRITE CODE HERE'''
