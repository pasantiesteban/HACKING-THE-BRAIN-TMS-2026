'''
 Using one return statement, complete the definition of the function 'swapints'
 so that it RETURNS the two values swapped.

 Example:
  Input:
  a = 5, b = 10

  Result:
  a = 10, b = 5
'''

def swapints(a, b):
    '''WRITE CODE HERE'''
