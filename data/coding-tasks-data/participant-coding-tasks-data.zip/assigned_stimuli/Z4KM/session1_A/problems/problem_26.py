'''
Clunker Motors Inc. is recalling all vehicles in its Extravagant line from model
 years 1999-2002. Given an int variable modelYear and a string modelName, print "RECALL"
 if modelYear and modelName match the recall details.
'''

modelYear = int(input())
modelName = input()

''' WRITE CODE HERE '''
