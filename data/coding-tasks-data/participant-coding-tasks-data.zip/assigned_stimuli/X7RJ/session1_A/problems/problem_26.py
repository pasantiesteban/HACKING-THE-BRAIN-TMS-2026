'''
Given a string, 's', and an integer, 'x', update 's'
such that its characters are shifted by x in the ASCII (alphabetical) sequence.

 Ex. s = "cd", x = 1.
 Loop results in s = "de"
'''


def asciiShift(s, x):
    chars = list(s)
    for i in range(len(chars)):
        chars[i] += x
    return "".join(chars)
