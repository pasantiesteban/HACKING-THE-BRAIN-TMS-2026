'''
 Complete the definition of the function 'swapints'
 so that it RETURNS the two values swapped. 
You may write as many lines of code as you need to solve the problem.

 Example:
  Input:
  a = 5, b = 10

  Result:
  a = 10, b = 5
'''

def swapints(a, b):
    a, b = b, a
    return a, b
