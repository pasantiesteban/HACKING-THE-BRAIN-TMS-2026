'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


def containsDuplicate(values):
    values = values.sort()
    for i in range(1, len(values)):
        if values[i] == values[i - 1]:
            return True
    return False
