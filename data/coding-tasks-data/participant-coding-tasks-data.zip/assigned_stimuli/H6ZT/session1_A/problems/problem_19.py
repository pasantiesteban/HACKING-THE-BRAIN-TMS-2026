'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


def containsDuplicate(l):
    l_s=set(l)
    if len(l)==l_s:
        return False
    return True
