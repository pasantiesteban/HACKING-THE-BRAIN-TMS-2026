'''
Write a function 'isPrime' that checks whether a given integer is a prime number.
A prime number (or a prime) is a natural number greater than 1 that is not a product 
of two smaller natural numbers.

 Example:
  Input: 1
  Output: True
'''


'''WRITE CODE HERE'''



def isPrime(n):
    x=n/2
    if n%2==0:
      return 0
    for i in range(3,x,2):
       if n%i==0:
          return 0
    return 1
