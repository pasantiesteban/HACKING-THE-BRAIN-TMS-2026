'''
Given a string, 's', and an integer, 'x', update 's'
such that its characters are shifted by x in the ASCII (alphabetical) sequence.

 Ex. s = "cd", x = 1.
 Loop results in s = "de"
'''


'''WRITE CODE HERE'''

def Loop(s,x):
    for i in range(len(s)):
        s[i]=s[i]+x