'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''


'''WRITE CODE HERE'''

def isSorted(vals):
    for i in len(vals)-1:
        if vals[i]>vals[i+1]:
            return False
    return True