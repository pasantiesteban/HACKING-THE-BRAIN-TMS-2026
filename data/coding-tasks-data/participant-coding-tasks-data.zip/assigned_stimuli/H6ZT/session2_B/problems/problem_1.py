'''
Implement a function 'secondGreatest' that accepts
a list of integers and returns the second greatest element in the list.

 Example:
  Input:
  values = [4, 9, 1, 7, 3]

  Output:
  7
'''

'''WRITE CODE HERE'''

def secondGreatest(vals):
    g=-1000
    sg=-1001
    for i in vals:
        if i>g:
            g=i
            continue
        if i<g and i>sg:
            sg=i
    return sg