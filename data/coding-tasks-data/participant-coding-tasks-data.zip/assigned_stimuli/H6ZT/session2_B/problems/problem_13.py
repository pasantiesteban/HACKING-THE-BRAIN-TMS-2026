'''
Write a simple Python program called "findmean" to find the mean value of a list of numbers
 The mean (also called the average) is the sum of all the numbers divided by how many numbers there are.

 Example:
  Input:
  numbers = [4, 8, 6, 2]

  Output:
  5
'''

def mean(n):
    sum=0
    for i in n:
        sum=sum+i
    return sum*1.0/len(n)

'''WRITE CODE HERE'''
