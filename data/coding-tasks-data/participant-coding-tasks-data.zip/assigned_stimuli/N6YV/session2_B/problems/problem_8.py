'''
Write a simple Python program called "findmean" to find the mean value of a list of numbers
 The mean (also called the average) is the sum of all the numbers divided by how many numbers there are.

 Example:
  Input:
  numbers = [4, 8, 6, 2]

  Output:
  5
'''


def findmean(numlist): 
  # avoid dividing by 0
  if not numlist: 
     return 0
  
  sum = 0
  for num in numlist:
      sum += num
  return sum / len(numlist)
