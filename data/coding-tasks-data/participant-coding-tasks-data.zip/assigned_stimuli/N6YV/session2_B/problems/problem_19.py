'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''


def isSorted(numlist):
  # each number must not be smaller than the one that came before
  for index, num in enumerate(numlist):
    if index == 0: 
      continue
    elif num < numlist[index - 1]:
      return False
  return True
    
