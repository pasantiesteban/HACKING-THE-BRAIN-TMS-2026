'''
Implement a function 'secondGreatest' that accepts
a list of integers and returns the second greatest element in the list.

 Example:
  Input:
  values = [4, 9, 1, 7, 3]

  Output:
  7
'''

def secondGreatest(intlist): 
  assert(len(intlist) >= 2)

  greatest = max(intlist[0], intlist[1])
  second = min(intlist[0], intlist[1])

  for int in intlist:
    if int > greatest: 
      second = greatest
      greatest = int
    elif int > second: 
      second = int

  return second


