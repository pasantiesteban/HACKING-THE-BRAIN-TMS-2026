''' 
Write the definition of a function 'min' that has two int parameters (num1, num2) and returns the smaller.
You may write as many lines of code as you need to solve the problem.

 Example:
  Input:
  num1 = 8, num2 = 3

  Output after calling min(num1, num2):
  3
'''

def min(num1, num2):
  if num1 < num2:
    return num1
  return num2
