"""
Complete the definition of a function 'max' that has three int parameters and returns the largest.

Example:
 Input:
 x = 4, y = 9, z = 2

 Output after calling max(x, y, z):
 9

"""

def max(x, y, z):
    if x > z and x > y:
        return x
    elif y > z and y > x:
        return y
    else:
        return z
