'''
Given a string, 's', and an integer, 'x', update 's'
such that its characters are shifted by x in the ASCII (alphabetical) sequence.

 Ex. s = "cd", x = 1.
 Loop results in s = "de"
'''


# I think strings are immutable in Python but can't remember how to get around that

def update_string(s, x):
    for i in range(s.len()):
        s[i] = chr(int(s[i]) + x)
    return s
