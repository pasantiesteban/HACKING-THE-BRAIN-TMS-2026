'''
Write a function 'isPrime' that checks whether a given integer is a prime number.
A prime number (or a prime) is a natural number greater than 1 that is not a product 
of two smaller natural numbers.

 Example:
  Input: 1
  Output: True
'''


def isPrime(x):
  if (x < 1):
    return False 
    # not a natural number
  elif (x == 1 or x == 2):
    return True

  # check if divisible by any number smaller than itself
  for i in range(2, x):
    if x % i == 0: 
      return False
  return True