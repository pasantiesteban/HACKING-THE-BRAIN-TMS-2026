'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


def containsDuplicate(intlist):
  # I don't know how to make a hash set in Python hahaha
  for i in range(intlist.len()):
    for j in range(intlist.len()):
      if i != j and intlist[i] == intlist[j]:
        return True
  return False
