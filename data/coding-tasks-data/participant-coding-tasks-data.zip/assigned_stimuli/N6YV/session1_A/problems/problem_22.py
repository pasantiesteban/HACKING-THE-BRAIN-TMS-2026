"""
Complete the definition of a function 'fibonacci' so
that it prints the series of numbers as the sum of the two preceding ones.
You may write as many lines of code as you need to solve the problem.

Example:
 Input:
 n = 7

 Output after calling fibonacci(n):
 0 1 1 2 3 5 8
"""

def fibonacci(n):
    if n == 0: 
        return 0

    elif n == 1:
        return 1

    return fibonacci(n - 1) + fibonacci(n - 2)
