"""
Given that a list of ints named 'a' has been initialized with 12 elements and that the integer
variable 'k' holds a value between 0 and 6. Assign 9 to the element just after a[k].
"""


# check that k is between 0 and 10
a[k + 1] = 9
