'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


def containsDuplicate(x):
    y = []
    for items in x:
        if items in y:
            return True
        else:
            y.append(items)

    return False
    
