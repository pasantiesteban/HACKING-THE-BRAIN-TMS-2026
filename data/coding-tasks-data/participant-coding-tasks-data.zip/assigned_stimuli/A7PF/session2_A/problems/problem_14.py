'''
Write the definition of a function 'isPositive', that receives an integer parameter and
 returns true if the parameter is positive, and false otherwise.

 Example:
  Before:
  num = -4

  After calling isPositive(num):
  false
'''



''' WRITE CODE HERE '''
def isPositive(n):
    if (n > 0):
        return True
    else:
        return False