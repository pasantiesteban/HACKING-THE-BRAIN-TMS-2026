'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''

def isSorted(x):
    for i in range(0, x.size() - 1):
        if (x[i] > x[i + 1]):
            return False
    
    return True
