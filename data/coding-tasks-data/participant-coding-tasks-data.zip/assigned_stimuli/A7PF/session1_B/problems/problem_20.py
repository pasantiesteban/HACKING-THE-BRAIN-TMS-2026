'''
Implement a function 'secondGreatest' that accepts
a list of integers and returns the second greatest element in the list.

 Example:
  Input:
  values = [4, 9, 1, 7, 3]

  Output:
  7
'''

def secondGreatest(x):
    x.sort()
    return x[1]
