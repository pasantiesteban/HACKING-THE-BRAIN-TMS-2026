"""
Complete the following code to merge two sorted lists into a new sorted list. 
Once the merge is done, return the merged list.

Example:
Input:
a = [1, 3, 5]
b = [2, 4, 6]

Output:
[1, 2, 3, 4, 5, 6]
"""

def merge(a, b):
    # create a new list
    merged = [0] * (len(a) + len(b))  # create a new list of a given size (initially 0s)
    # initialize all of the indices
    index_a = 0
    index_b = 0
    index_m = 0
    
    # add correct values to the new list
    while index_a < a.size() and index_b < b.size():
        if a[index_a] < b[index_b]:
            merged[index_m] = a[index_a]
            index_a += 1
        else:
            merged[index_m] = b[index_b]
            index_b += 1
        index_m += 1
    
    # need to do some additional copying work here
    
    if (index_a == a.size()):
        for i in range(index_b, b.size()):
            merged[index_m] = b[index_b]
            index_m += 1
    elif (index_b == b.size()):
        for i in range(index_a, a.size()):
            merged[index_m] = a[index_a]
            index_m += 1










    return merged