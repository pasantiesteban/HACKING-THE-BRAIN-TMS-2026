"""
Complete the function "triangle" so that the output looks like a triangle made up of "*".

Example:
 Input:
 value = 5

 Output after calling triangle(value):
 *****
 ****
 ***
 **
 *
"""

def triangle(value):
    for i in range(value, 0, -1):
        for  j in range(0,value,1):
            print("*", end="")
        print()
    return
