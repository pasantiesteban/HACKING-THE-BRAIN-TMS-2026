'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''


'''WRITE CODE HERE'''
for i in range(n):
    if input[i]<=input(i+1):
        return True
    
return False
