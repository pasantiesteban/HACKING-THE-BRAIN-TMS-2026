"""
Complete the for loop such that it prints the odd integers
11 through 121 inclusive, separated by spaces.

Example Output:
11 13 15 ... 119 121
"""

for i in range(11,121,+2):
    print(i, end=" ")