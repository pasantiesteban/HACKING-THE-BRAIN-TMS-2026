'''
Implement a function 'secondGreatest' that accepts
a list of integers and returns the second greatest element in the list.

 Example:
  Input:
  values = [4, 9, 1, 7, 3]

  Output:
  7
'''

'''WRITE CODE HERE'''

greatest=None
for i in range values.len :
  if values[i+1]>values[i]:
    values[i+1]=greatest

print(greatest)

