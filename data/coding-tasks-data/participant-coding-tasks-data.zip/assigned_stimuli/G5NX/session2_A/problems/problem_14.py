"""
Complete the assignment of the variable 'isFailing' such that it is set to True if 'exam_score' is
less than 50, and False otherwise.
"""

def checkExam():
    exam_score = int(input())
    if(exam_score<50):
        tmp=True
    else: tmp=False
    isFailing =tmp
    if isFailing:
        print("You failed!")
    else:
        print("You passed!")
