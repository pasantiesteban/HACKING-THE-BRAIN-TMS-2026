'''
Write a function 'isPrime' that checks whether a given integer is a prime number.
A prime number (or a prime) is a natural number greater than 1 that is not a product 
of two smaller natural numbers.

 Example:
  Input: 1
  Output: True
'''


'''WRITE CODE HERE'''
def isPrime(num):
    count=0
    i=1
    while(i<=num):
        if(num%i==0):
            count=count+1
    
    if(count<=2):
        return True
    else:
        return False
