'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


''' WRITE CODE HERE '''
def containsDuplicate(values):
    for i in range(values.len):
        for j in range(values.len):
            if(values[i]==values[j]):
                return True
  
    return False
