'''
Implement a function 'containsDuplicate' that accepts a list of integers and
returns True if it contains a duplicate element, and False otherwise.

 Example:
  Input:
  values = [3, 1, 4, 2, 1]

  Output:
  True
'''


def containsDuplicate(nums):
    for i in nums:
        if nums.count(i) > 1:
            return True
        
    return False