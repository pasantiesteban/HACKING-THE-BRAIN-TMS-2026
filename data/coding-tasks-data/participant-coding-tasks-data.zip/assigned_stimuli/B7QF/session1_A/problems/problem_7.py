'''
Clunker Motors Inc. is recalling all vehicles in its "Extravagant" line from model
 years 1999-2002. Given an int variable modelYear (e.g., 1998) and a string modelName (e.g., "Extravagant"), print "RECALL"
 if modelYear and modelName match the recall details. Otherwise, print nothing.
'''

modelYear = int(input())
modelName = input()

if modelName == "Extravagant" and (modelYear in range(1999, 2003)):
    print("RECALL")