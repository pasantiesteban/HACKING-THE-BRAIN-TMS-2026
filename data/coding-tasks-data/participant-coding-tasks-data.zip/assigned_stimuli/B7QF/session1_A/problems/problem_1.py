'''
Write a function 'isPrime' that checks whether a given integer is a prime number.
A prime number (or a prime) is a natural number greater than 1 that is not a product 
of two smaller natural numbers.

 Example:
  Input: 1
  Output: True
'''


def isPrime(n):
  num_fac = 0
  for i in range(1, n+1):
    if n % i == 0:
      num_fac += 1
  
  return num_fac == 2
