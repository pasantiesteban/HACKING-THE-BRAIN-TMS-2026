'''
Given a string, 's', and an integer, 'x', update 's'
such that its characters are shifted by x in the ASCII (alphabetical) sequence.

 Ex. s = "cd", x = 1.
 Loop results in s = "de"
'''

def shift(s, x):
    letters = []
    for c in s:
        letters.append(chr(ord(c) + x))
    return ''.join(letters)