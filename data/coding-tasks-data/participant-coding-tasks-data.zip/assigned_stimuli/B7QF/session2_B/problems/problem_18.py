'''
Write the definition of the function 'factorial' where it
outputs the factorial of non-negative integer n.
The factorial of a non-negative integer n, denoted by n!, is the product of 
all positive integers less than or equal to n (e.g. factorial four ( 4! ) is equal to 24.)

 Example:
  Input:
  n = 5

  Output:
  120
'''


def factorial(n):
    if n == 0 or n == 1:
        return 1
    
    return n * factorial(n - 1)
