'''
Write a for loop that prints the integers 1 through 40,
separated by spaces or new lines. You may use only one variable, 'count'.

 Example:
  Output:
  1 2 3 4 ... 39 40
'''

count = 1
while count <= 40:
    print(count, end=' ')
    count += 1
