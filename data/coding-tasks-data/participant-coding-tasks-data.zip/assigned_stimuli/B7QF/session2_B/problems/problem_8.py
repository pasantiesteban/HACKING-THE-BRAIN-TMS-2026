''' 
Use a for loop to print a single line consisting of 97 asterisks. 
Use no variables other than 'k'.
'''

for k in range(97):
    print("*", end="")
print()
