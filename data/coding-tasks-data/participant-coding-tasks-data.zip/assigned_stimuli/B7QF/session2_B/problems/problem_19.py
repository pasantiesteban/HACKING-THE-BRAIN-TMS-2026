'''
Implement a function 'secondGreatest' that accepts
a list of integers and returns the second greatest element in the list.

 Example:
  Input:
  values = [4, 9, 1, 7, 3]

  Output:
  7
'''

'''WRITE CODE HERE'''


def secondGreatest(values):
    
    greatest = 0
    second_greatest = 0

    for x in values:
        
        if x > greatest:
            second_greatest = greatest
            greatest = x

        elif x > second_greatest:
            second_greatest = x
    
    return second_greatest

