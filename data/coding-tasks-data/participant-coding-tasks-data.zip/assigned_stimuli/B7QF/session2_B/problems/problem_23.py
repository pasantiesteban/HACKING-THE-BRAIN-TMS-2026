'''
Implement a function 'isSorted' that accepts a list of integer values
 and returns true if it is non-decreasing,
 and false otherwise

 Example:
  Input: [1, 2, 2, 4, 7]

  Output: true
'''


def isSorted(values):
    
    for i in range(len(values) - 1):
        if values[i+1] < values[i]:
            return False
      
    return True